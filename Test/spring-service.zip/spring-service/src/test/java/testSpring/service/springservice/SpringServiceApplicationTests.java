package testSpring.service.springservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
